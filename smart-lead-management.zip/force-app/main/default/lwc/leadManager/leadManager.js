import { LightningElement } from 'lwc';
import createLead from '@salesforce/apex/LeadService.createLead';

export default class LeadManager extends LightningElement {

    name;
    email;

    handleName(event){
        this.name = event.target.value;
    }

    handleEmail(event){
        this.email = event.target.value;
    }

    createLead(){
        createLead({name: this.name, email: this.email})
        .then(() => {
            alert('Lead Created Successfully');
        })
        .catch(error => {
            console.error(error);
        });
    }
}