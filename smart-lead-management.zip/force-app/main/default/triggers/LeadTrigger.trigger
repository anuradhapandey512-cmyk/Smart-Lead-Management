trigger LeadTrigger on Lead (before insert) {
    for(Lead l : Trigger.new){
        List<Lead> existing = [SELECT Id FROM Lead WHERE Email = :l.Email LIMIT 1];
        if(!existing.isEmpty()){
            l.addError('Duplicate Email Found!');
        }
    }
}